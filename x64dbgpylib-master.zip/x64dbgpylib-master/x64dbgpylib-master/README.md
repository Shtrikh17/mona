# x64dbgpylib

Port of [windbglib](https://github.com/corelan/windbglib) to [x64dbgpy](https://github.com/x64dbg/x64dbgpy), in an effort to support [mona.py](https://github.com/corelan/mona) in [x64dbg](http://x64dbg.com).

**This is a work in progress, see the [issues](https://github.com/x64dbg/x64dbgpylib/issues) or [contact us](http://x64dbg.com/#contact) to find out how you can help**. In particular, [this issue](https://github.com/x64dbg/x64dbgpylib/issues/5) has the current state of support for mona commands; any help on the remaining commands would be appreciated.
